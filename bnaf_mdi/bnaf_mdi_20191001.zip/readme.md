## 1. prepare dataset

## 2. run bnaf
run run_bnaf.sh to transform data

## 3. run mdi
run run_mdi.sh to see result

if use bnaf, set param_usebnaf = 1
else, set param_usebnaf=0